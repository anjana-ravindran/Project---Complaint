﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Online_Product_Complaint_System.DAL
{
    public class ComplaintDAL
    {
        public SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        public ComplaintDAL()
        {
            //call connectionstring;connection string should be set in the web.config file.
            string conn = ConfigurationManager.ConnectionStrings["rose"].ConnectionString;
            con = new SqlConnection(conn);
            cmd.Connection = con;
        }
        public SqlConnection Getcon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            return con;
        }
        public DataSet productValues(int productid)
        {
            string qry = "select  * from tbl_Product_Registration where Product_id='" + productid + "'";
            SqlCommand cmd = new SqlCommand(qry, Getcon());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet(); 
            cmd.ExecuteNonQuery(); 
            da.Fill(ds); 
            return ds;
        }
        public DataTable productList()
        {

            string qry = "select  * from tbl_Product_Registration";
            SqlCommand cmd = new SqlCommand(qry, Getcon());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable ds = new DataTable();
            da.Fill(ds);
            return ds;
        }
        public int complaintInsert(BAL.ComplaintBAL obj)
        {
            string qry = "insert into tbl_Complaint values('" + obj.UserId + "','" + obj.ProductId+ "','" + DateTime.Now.ToLongDateString().ToString() + "','" + obj.ProductComplaintDescription+ "','Complaint Received')";
            SqlCommand cmd = new SqlCommand(qry, Getcon());
            return cmd.ExecuteNonQuery();
        }
        public DataTable complaintView(BAL.ComplaintBAL obj)
        {
            //string qry = "select r.*,d.* from CompReg d INNER JOIN Product r  ON r.productid=d.productid AND user_id='" + obj.user_id +"'";
            string s = "select * from tbl_Complaint c inner join tbl_User_Registration r on c.User_id=r.User_id inner join tbl_Product_Registration p on p.Product_id=c.Product_id";
           // "select * from tbl_Registration tb inner join tbl_Complaint cmt on tb.User_id=cmt.User_id inner join tbl_Product pt on pt.Product_id=cmt.Product_id";
            SqlCommand cmd = new SqlCommand(s, Getcon());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public DataTable complaintUserView(BAL.ComplaintBAL obj)
        {
            string qry = "select * from tbl_Complaint c inner join tbl_User_Registration r on c.User_id=r.User_id inner join tbl_Product_Registration p on p.Product_id=c.Product_id AND c.User_id ='"+obj.UserId+"'";
            SqlCommand cmd = new SqlCommand(qry, Getcon());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;

        }

        public int statusUpdate(BAL.ComplaintBAL obj)
        {
            string s = "update tbl_Complaint set Status='" + obj.ComplaintStatus + "' where Complaint_id='" + obj.ComplaintId + "'";
            SqlCommand cmd = new SqlCommand(s, Getcon());
            return cmd.ExecuteNonQuery();
        }
    }
}