﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Online_Product_Complaint_System.DAL
{
    public class UserRegistrationDAL
    {
        public SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        public UserRegistrationDAL()
        {
            //call connectionstring;connection string should be set in the web.config file.
            string conn = ConfigurationManager.ConnectionStrings["rose"].ConnectionString;
            con = new SqlConnection(conn); 
            cmd.Connection = con;
        }
        public SqlConnection Getcon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            return con;
        }
        public object loginInsert(BAL.UserRegistrationBAL obj)
        {
            Getcon();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into tbl_Login values('" + obj.NameUser + "','" + obj.UserPassword+ "','Not Confirmed','User');select @@IDENTITY";
            object id = cmd.ExecuteScalar();
            return id;
        }
        public int userInsert(BAL.UserRegistrationBAL obj)
        {
            string qry = "insert into tbl_User_Registration values('" + obj.UserName + "','" + obj.UserEmail + "','" + obj.UserPhone + "','"+obj.Loginid+"')";
            SqlCommand cmd = new SqlCommand(qry, Getcon());
            return cmd.ExecuteNonQuery();
        }

        public int loginUser(BAL.UserRegistrationBAL obj)
        {
            string s = "select count(*) from tbl_Login where Username='" + obj.NameUser + "'and Password='" + obj.UserPassword + "'";
            SqlCommand cmd = new SqlCommand(s, Getcon());
            int row = (int)cmd.ExecuteScalar();
            return row;
        }
        public DataTable viewUser()
        {
            string s = "select * from tbl_User_Registration t inner join tbl_Login l on l.Login_id=t.Login_id where Status='Not Confirmed'";
            SqlCommand cmd = new SqlCommand(s, Getcon());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;

        }
        public int Confirmupdate(BAL.UserRegistrationBAL obj)
        {
            string s = "update tbl_login set Status='Confirmed' where Login_id='" + obj.Loginid + "'";
            SqlCommand cmd = new SqlCommand(s, Getcon());
            return cmd.ExecuteNonQuery();
        }
    }
}
