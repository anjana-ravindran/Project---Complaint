﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;

namespace Online_Product_Complaint_System.DAL
{
    public class LoginDAL
    {
       // BAL.LoginBAL objloginbal = new BAL.LoginBAL();
        public SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        public LoginDAL()
        {
            //call connectionstring;connection string should be set in the web.config file.
            string conn = ConfigurationManager.ConnectionStrings["rose"].ConnectionString;
            con = new SqlConnection(conn);
            cmd.Connection = con;
        }
        public SqlConnection Getcon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            return con;
        }
        public DataTable CheckLogin(BAL.LoginBAL obj)
        {
            string qry = "Select * from tbl_Login Where Username='" + obj.User + "' and Password='" + obj.UserPassword + "'";
            SqlCommand cmd = new SqlCommand(qry, Getcon());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
            
        }
    }
}