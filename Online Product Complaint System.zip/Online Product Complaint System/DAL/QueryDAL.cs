﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Online_Product_Complaint_System.DAL
{
    public class QueryDAL
    {
    }
}