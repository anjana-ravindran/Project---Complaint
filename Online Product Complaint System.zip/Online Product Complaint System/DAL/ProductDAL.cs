﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Online_Product_Complaint_System.DAL
{

    public class ProductDAL
    {
        public SqlConnection con = new SqlConnection();
        SqlCommand cmd = new SqlCommand();
        public ProductDAL()
        {
            //call connectionstring;connection string should be set in the web.config file.
            string conn = ConfigurationManager.ConnectionStrings["rose"].ConnectionString;
            con = new SqlConnection(conn);
            cmd.Connection = con;
        }
        public SqlConnection Getcon()
        {
            if (con.State == ConnectionState.Closed)
            {
                con.Open();
            }
            return con;
        }
        public int productInsert(BAL.ProductBAL obj)
        {
            string qry = "insert into tbl_Product_Registration values('" + obj.ProductName + "','" + obj.ProductDescription + "')";
            SqlCommand cmd = new SqlCommand(qry, Getcon());
            return cmd.ExecuteNonQuery();
        }
        public DataTable productView()
        {
            string s = "select * from tbl_Product_Registration ";
            SqlCommand cmd = new SqlCommand(s, Getcon());
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;

        }
        public int productUpdate(BAL.ProductBAL obj)
        {
            string s = "update tbl_Product_Registration set Product_Name='" + obj.ProductName + "',Description='"+obj.ProductDescription+"' where Product_id='" + obj.ProductId + "'";
            SqlCommand cmd = new SqlCommand(s, Getcon());
            return cmd.ExecuteNonQuery();

        }
        public int productDelete(BAL.ProductBAL obj)
        {
            string s = "Delete from tbl_Product_Registration where Product_id='" + obj.ProductId + "'";
            SqlCommand cmd = new SqlCommand(s, Getcon());
            return cmd.ExecuteNonQuery();

        }
    }
}