﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Product_Complaint_System.Admin
{
    public partial class ViewComplaint : System.Web.UI.Page
    {
        BAL.ComplaintBAL objcomplaintbal = new BAL.ComplaintBAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GridView1.DataSource = objcomplaintbal.viewComplaint();
                GridView1.DataBind();

            }
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            GridView1.DataSource = objcomplaintbal.viewComplaint();
            GridView1.DataBind();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value.ToString());
            TextBox txtstatus = new TextBox();
            txtstatus = (TextBox)GridView1.Rows[e.RowIndex].Cells[5].Controls[0];
            objcomplaintbal.ComplaintId = id;
            objcomplaintbal.ComplaintStatus= txtstatus.Text;
            int i = objcomplaintbal.updateStatus();
            GridView1.EditIndex = -1;
            GridView1.DataSource = objcomplaintbal.viewComplaint();
            GridView1.DataBind();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            GridView1.DataSource = objcomplaintbal.viewComplaint();
            GridView1.DataBind();
        }
    }
}