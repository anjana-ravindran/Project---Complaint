﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Product_Complaint_System.Admin
{
    public partial class AddProduct : System.Web.UI.Page
    {
        BAL.ProductBAL objproducttbl = new BAL.ProductBAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                GridView1.DataSource = objproducttbl.viewProduct();
                GridView1.DataBind();
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            objproducttbl.ProductName = txtname.Text;
            objproducttbl.ProductDescription = txtdescription.Text;
            int i = objproducttbl.insertProduct();
            txtname.Text = "";
            txtdescription.Text = "";
            GridView1.DataSource = objproducttbl.viewProduct();
            GridView1.DataBind();
            if (i == 1)
            {
                Response.Write("<script>alert('Inserted Successfully');</script>");
            }
            else
            {
                Response.Write("<script>alert('Insertion Failed');</script>");
            }
           
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            
            int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value.ToString());
            TextBox txtproductname = new TextBox();
            txtproductname = (TextBox)GridView1.Rows[e.RowIndex].Cells[1].Controls[0];
            TextBox txtdescription = new TextBox();
            txtdescription = (TextBox)GridView1.Rows[e.RowIndex].Cells[2].Controls[0];
            objproducttbl.ProductId= id;
            objproducttbl.ProductName = txtproductname.Text;
            objproducttbl.ProductDescription = txtdescription.Text;
            int i = objproducttbl.updateProduct();
            GridView1.EditIndex = -1;
            GridView1.DataSource = objproducttbl.viewProduct();
            GridView1.DataBind();


        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            GridView1.DataSource = objproducttbl.viewProduct();
            GridView1.DataBind();
        }

    

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value.ToString());
            objproducttbl.ProductId = id;
            int i = objproducttbl.deleteProduct();
            GridView1.EditIndex = -1;
            GridView1.DataSource = objproducttbl.viewProduct();
            GridView1.DataBind();
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            GridView1.DataSource = objproducttbl.viewProduct();
            GridView1.DataBind();

        }
    }
}