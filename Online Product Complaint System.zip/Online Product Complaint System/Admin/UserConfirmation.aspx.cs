﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Product_Complaint_System.Admin
{
    public partial class UserConfirmation : System.Web.UI.Page
    {
        BAL.UserRegistrationBAL objuserconfirmtbl = new BAL.UserRegistrationBAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GridView1.DataSource = objuserconfirmtbl.viewUserConfirmDetails();
                GridView1.DataBind();
            }
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

            int id = Convert.ToInt32(GridView1.DataKeys[e.RowIndex].Value.ToString());
            objuserconfirmtbl.Loginid = id.ToString();
            int i = objuserconfirmtbl.Updateconfirm();
            GridView1.DataSource = objuserconfirmtbl.viewUserConfirmDetails();
            GridView1.DataBind();


        }
    }
}