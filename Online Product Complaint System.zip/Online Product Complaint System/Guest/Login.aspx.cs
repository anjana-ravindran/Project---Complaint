﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Product_Complaint_System.Guest
{
    public partial class Login : System.Web.UI.Page
    {
        BAL.LoginBAL objlogindal = new BAL.LoginBAL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Login_Click(object sender, EventArgs e)
        {
           objlogindal.User = txtuname.Text;
           objlogindal.UserPassword = txtpassword.Text;
            DataTable dt = objlogindal.LoginCheck();
            if (dt.Rows.Count == 1)
            {
                Session["uname"] = dt.Rows[0]["Username"].ToString();
                Session["lid"] = dt.Rows[0]["Login_id"].ToString();

                if (dt.Rows[0]["Type"].ToString() == "Admin")
                    Response.Redirect("../Admin/AdminHome.aspx");
                else if (dt.Rows[0]["Type"].ToString() == "User")
                    if (dt.Rows[0]["Status"].ToString() == "Confirmed")
                        Response.Redirect("../User/UserHome.aspx");
                    else
                        Response.Write("<script>alert('User Not Verified');</script>");
                else
                    Response.Write("<script>alert('Invalid Credentials');</script>");




            }


        }
    }
}