﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Product_Complaint_System
{
    public partial class UserRegistration : System.Web.UI.Page
    {
        BAL.UserRegistrationBAL objusertbl = new BAL.UserRegistrationBAL();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_Register_Click(object sender, EventArgs e)
        {
            objusertbl.UserName =txtname.Text;
            objusertbl.UserEmail = txtemail.Text;
            objusertbl.UserPhone = txtphone.Text;
            objusertbl.NameUser = txtusername.Text;
            objusertbl.UserPassword = txtpassword.Text;
            object ob= objusertbl.insertLogin();
            objusertbl.Loginid = ob;
            int j = objusertbl.insertUser();
            Response.Write("<script>alert('Inserted Successfully');</script>");

        }
    }
}