﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Product_Complaint_System.User
{
    public partial class ViewComplaint : System.Web.UI.Page
    {
        BAL.ComplaintBAL objcomplaintbal = new BAL.ComplaintBAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                objcomplaintbal.UserId = Convert.ToInt32(Session["lid"]);
                GridView1.DataSource = objcomplaintbal.userviewComplaint();
                GridView1.DataBind();
            }

        }
    }
}