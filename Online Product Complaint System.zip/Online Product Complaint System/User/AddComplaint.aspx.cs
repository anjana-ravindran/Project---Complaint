﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Online_Product_Complaint_System.User
{
    public partial class ComplaintRegistration : System.Web.UI.Page
    {
        BAL.ComplaintBAL objcomplaintdl = new BAL.ComplaintBAL();
      //  int cid;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                productidBind();
                lbldate.Text = DateTime.Now.ToLongDateString().ToString();
            }

        }
        public void productidBind()
        {
            DataTable prod = objcomplaintdl.productValues();
            ddlproduct.DataSource= objcomplaintdl.productValues();
            ddlproduct.DataTextField = "Product_Name";
            ddlproduct.DataValueField = "Product_id";
            ddlproduct.DataBind();
            ddlproduct.Items.Insert(0, new ListItem("-- Select --", "0"));
        } 



        protected void btn_Add_Click(object sender, EventArgs e)
        {
            objcomplaintdl.ProductId = Convert.ToInt32(ddlproduct.SelectedValue);
            objcomplaintdl.UserId = Convert.ToInt32(Session["lid"]);
            objcomplaintdl.ProductComplaintDescription = txtdescription.Text;
            int i = objcomplaintdl.insertComplaint();
            if (i == 1)
            {
                Response.Write("<script>alert('Complaint Registered Successfully');</script>");
                //ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('" + "Complaint Registered Successfully" + "');");
            }
        }
    }
}