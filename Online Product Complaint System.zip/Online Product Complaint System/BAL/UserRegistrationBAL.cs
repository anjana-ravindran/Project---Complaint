﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Online_Product_Complaint_System.BAL
{
    public class UserRegistrationBAL
    {
        DAL.UserRegistrationDAL objuserDAL = new DAL.UserRegistrationDAL();
        private string _userid;
        private string _username;
        private string _useremail;
        private string _userphone;
        private string _nameuser;
        private string _userpassword;
        public object _loginid;


        //private string -deptdescription
        public string UserId
        {
            get
            {
                return _userid;
            }
            set
            {
                _userid = value;
            }

        }
        public string UserName
        {
            get
            {
                return _username;
            }
            set
            {
                _username = value;
            }

        }
        public string UserEmail
        {
            get
            {
                return _useremail;
            }
            set
            {
                _useremail = value;
            }

        }
        public string UserPhone
        {
            get
            {
                return _userphone;
            }
            set
            {
                _userphone = value;
            }

        }
        public string NameUser
        {
            get
            {
                return _nameuser;
            }
            set
            {
                _nameuser = value;
            }

        }
        public string UserPassword
        {
            get
            {
                return _userpassword;
            }
            set
            {
                _userpassword = value;
            }

        }
        public object Loginid
        {
            get
            {
                return _loginid;
            }
            set
            {
                _loginid = value;
            }
        }

        public int insertUser()
        {
            return objuserDAL.userInsert(this);
        }
        public object insertLogin()
        {
            return objuserDAL.loginInsert(this);
        }
        public DataTable viewUserConfirmDetails()
        {
            return objuserDAL.viewUser();
        }
        public int Updateconfirm()
        {
            return objuserDAL.Confirmupdate(this);
        }
    }
}