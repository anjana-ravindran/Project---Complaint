﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Online_Product_Complaint_System.BAL
{
    public class LoginBAL
    {
        DAL.LoginDAL objlogindal = new DAL.LoginDAL();
        private int _user_id;
        private string _user_name;
        private string _user_password;
        public int UserId
        {
            get
            {
                return _user_id;
            }
            set
            {
                _user_id = value;
            }

        } 

        public string User
        {
            get
            {
                return _user_name;
            }
            set
            {
                _user_name = value;
            }

        }
        public string UserPassword
        {
            get
            {
                return _user_password;
            }
            set
            {
                _user_password = value;
            }

        }
        
        public DataTable LoginCheck()
        {
            return objlogindal.CheckLogin(this);
        }

    }
}