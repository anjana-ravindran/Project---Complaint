﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Online_Product_Complaint_System.BAL
{
    public class ComplaintBAL
    {
        DAL.ComplaintDAL objcomplaintDAL = new DAL.ComplaintDAL();
        private int _complaintid;
        private int _userid;
        private int _productid;
        private DateTime date;
        private string _description;
        private string _complaintstatus;
        public int ComplaintId
        {
            get
            {
                return _complaintid;
            }
            set
            {
                _complaintid = value;
            }

        }
        public int UserId
        {
            get
            {
                return _userid;
            }
            set
            {
                _userid = value;
            }

        }
        public int ProductId
        {
            get
            {
                return _productid;
            }
            set
            {
                _productid = value;
            }

        }
        public DateTime ProductDate
        {
            get
            {
                return date;
            }
            set
            {
                date = value;
            }
        }
        public string ProductComplaintDescription   
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
            }

        }
        public string ComplaintStatus
        {
            get
            {
                return _complaintstatus;
            }
            set
            {
                _complaintstatus = value;
            }

        }
        public int insertComplaint()
        {
            return objcomplaintDAL.complaintInsert(this);
        }
        public DataTable productValues()
        {
            return objcomplaintDAL.productList();
        }
        public DataTable viewComplaint()
        {
            return objcomplaintDAL.complaintView(this);
        }

        public int updateStatus()
        {
            return objcomplaintDAL.statusUpdate(this);
        }

        public DataTable userviewComplaint()
        {
            return objcomplaintDAL.complaintUserView(this);
        }
    }
}