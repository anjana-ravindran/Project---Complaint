﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Online_Product_Complaint_System.BAL
{
    public class ProductBAL
    {
        DAL.ProductDAL objproductDAL = new DAL.ProductDAL();

        private int _productid;
        private string _productname;
        private string _productdescription;
        public int ProductId
        {
            get
            {
                return _productid;
            }
            set
            {
                _productid = value;
            }

        }
        public string ProductName
        {
            get
            {
                return _productname;
            }
            set
            {
                _productname = value;
            }

        }
        public string ProductDescription
        {
            get
            {
                return _productdescription;
            }
            set
            {
                _productdescription = value;
            }

        }
        public int insertProduct()
        {
            return objproductDAL.productInsert(this);
        }
        public DataTable viewProduct()
        {
            return objproductDAL.productView();
        }
        public int updateProduct()
        {
            return objproductDAL.productUpdate(this);
        }

        public int deleteProduct()
        {
            return objproductDAL.productDelete(this);
        }
    }
}