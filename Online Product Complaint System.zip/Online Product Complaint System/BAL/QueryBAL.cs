﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Online_Product_Complaint_System.BAL
{
    public class QueryBAL
    {
       // DAL.QueryDAL objquery
    }
}